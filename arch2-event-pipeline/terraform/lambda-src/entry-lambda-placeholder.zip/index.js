// PLACEHOLDER - terraform이 최초 생성 시에만 사용하는 더미 코드입니다.
// 실제 배포는 CI/CD 파이프라인에서 `aws lambda update-function-code`로 이루어지며,
// 이 zip 내용은 이후 apply에서 무시됩니다 (lifecycle.ignore_changes 참고).
exports.handler = async () => {
  return { statusCode: 501, body: "placeholder - real code not deployed yet" };
};
