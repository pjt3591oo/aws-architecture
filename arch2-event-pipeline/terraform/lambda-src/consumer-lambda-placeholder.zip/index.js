// PLACEHOLDER - terraform이 최초 생성 시에만 사용하는 더미 코드입니다.
exports.handler = async () => {
  console.log("placeholder consumer - real code not deployed yet");
};
